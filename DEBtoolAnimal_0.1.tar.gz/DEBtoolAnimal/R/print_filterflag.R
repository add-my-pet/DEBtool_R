#' Prints an explanation of the filter flag onto the screen
#'
#' @description Prints an explanation to the screen according to the flag produced by a filter.
#' Meant to be run in the estimation procedure for the seed parameter set
#' @family add-my-pet auxiliary functions
#' @param flag integer with code from filter
#' @return list with updated par, units, label and free
#' @examples pars_init_my_pet(metaData)
#' @export
print_filterflag <- function(flag){

    switch(toString(flag),
         "1" = cat("One or more parameters are negative \n"),
         "2" = cat("kappa, f or one of the fractions is bigger than 1 \n"),
         "3" = cat("growth efficiency is bigger than 1 \n"),
         "4" = cat("maturity levels are not in the correct order \n"),
         "5" = cat("puberty or birth cannot be reached \n")
  )

}
