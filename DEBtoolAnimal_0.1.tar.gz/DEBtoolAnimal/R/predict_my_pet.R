#' Obtains predictions, using parameters and data
#'
#' @description Obtains predictions, using parameters and data
#' @family add-my-pet template functions
#' @param par data frame with parameter values
#' @param data data frame with data values
#' @param auxData data frame with auxiliary data values
#' @return list with prdData (data frame with values of predictions) and info (indicator for customized filters)
#' @examples predict_my_pet(par, data, auxData)
#' @export
predict_my_pet <- function(par, data, auxData = list()){

  compPar <- parscomp(par);
  with(as.list(par), with(as.list(compPar), with(as.list(data), with(as.list(auxData), {

    # customized filters for allowable parameters of the standard DEB model (std)
    # for other models consult the appropriate filter function.
    filterChecks <- k * v.Hp >= f.tL^3 ||   # constraint required for reaching puberty with f.tL
      !reach_birth(g, k, v.Hb, f.tL);       # constraint required for reaching birth with f.tL

    if(filterChecks)
      return(prdData <- list(), info <- 0)

    # compute temperature correction factors
    TC.ab = tempcorr(temp$ab, T.ref, T.A);
    TC.ap = tempcorr(temp$ap, T.ref, T.A);
    TC.am = tempcorr(temp$am, T.ref, T.A);
    TC.Ri = tempcorr(temp$Ri, T.ref, T.A);
    TC.tL = tempcorr(temp$tL, T.ref, T.A);






  }))))

  return(list(data = data, auxData = auxData, metaData = metaData, txtData = txtData, weights = weights))
}
