#' Filters for allowed parameters of standard DEB model without acceleration
#'
#' @description Checks if parameter values are in the allowable part of the parameter space of
#' standard DEB model without acceleration. Meant to be run in the estimation procedure
#' @family add-my-pet auxiliary functions
#' @param par data frame with parameter values
#' @details The flag is an indicator of reason for not passing the filter and it means
#' 0: parameters pass the filter
#' 1: some parameter is negative
#' 2: some kappa is larger than 1
#' 3: growth efficiency is larger than 1
#' 4: maturity levels do not increase during life cycle
#' 5: puberty cannot be reached
#' @return list with filter and flag
#' @examples filter_std(par)
#' @export
filter_std <- function(par){

  with(as.list(par), {

    filter <- 0; flag <- 0; # default setting of filter and flag

    parvec = c(z, v, kap, p.M, E.G, k.J, E.Hb, E.Hp, kap.R, h.a, s.G, T.A)
    if(any(parvec <= 0) || p.T < 0) {
      flag <- 1
      stop()
    }

  return(list(filter, flag))

  })
}




# if p.E_Hb >= p.E_Hp % maturity at birth, puberty
# flag = 4;
# return;
# end
#
# if p.f > 1
# flag = 2;
# return;
# end
#
# parvec = [p.kap; p.kap_R; p.kap_X; p.kap_P];
#
# if sum(parvec >= 1) > 0
# flag = 2;
# return;
# end
#
# % compute and unpack cpar (compound parameters)
# c = parscomp_st(p);
#
# if c.kap_G >= 1 % growth efficiency
# flag = 3;
# return;
# end
#
# if c.k * c.v_Hp >= p.f^3 % constraint required for reaching puberty
# flag = 5;
# return;
# end
#
# if ~reach_birth(c.g, c.k, c.v_Hb, p.f) % constraint required for reaching birth
# flag = 6;
# return;
# end
#
# filter = 1;
